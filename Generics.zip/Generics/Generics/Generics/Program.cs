﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Generics
{
    class FooGenerics<T>
    {
        T[] value = new T[2];
        int size = 0;
        public void Add(T input)
        {
            value[size] = input;
            Interlocked.Increment(ref size);
        }

        public T[] Get()
        {
            return value;
        }
    }

    class FooList<T> : List<T>
    {

    }


    class Program
    {
        static void Main(string[] args)
        {
            FooGenerics<string> fooGenerics = new FooGenerics<string>();
            fooGenerics.Add("hello");
            fooGenerics.Add("World!"); 
            Console.WriteLine(fooGenerics.GetType());


            var List = fooGenerics.Get();
            foreach (var item in List)
            {
                Console.WriteLine(item);
            }

            List<int> myList = new List<int>();
            int[] array = new int[] { 1,2,3,4,5 };
            int[] array2 = new int[] { 1, 6, 7, 8, 9, 5 };

            array = array.Where(q => !array2.Any(q2 => q2 == q)).ToArray();

            bool arrayHasTheValue = array.Contains(1);

            foreach (var item in array)
            {
                Console.WriteLine(item);
            }

            int lastIndexOfarray = array.Length;

            Array.Resize(ref array, array.Length + 1);
            array[lastIndexOfarray] = 100;

            foreach (var item in array)
            {
                Console.WriteLine(item);
            }

            List<int> listArray = array.ToList();

            foreach (var item in listArray)
            {
                Console.WriteLine(item);
            }
          
            bool hasTheValue = myList.Contains(1);
            Console.WriteLine(hasTheValue);
        }
    }
}
